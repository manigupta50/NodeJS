// Please don't change the pre-written code
// Import the necessary modules here

export const userController = async (req, res) => {
  const userData = await userModel();
  // Write your code here 
};
