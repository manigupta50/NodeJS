// Please don't change the pre-written code
// Import the necessary modules here

export const userRegisterationRepo = async (userData) => {
  // Write your code here
};
export const userLoginRepo = async (userData) => {
  // Write your code here
};

export const updateUserPasswordRepo = async (_id, newpassword, next) => {
  // Write your code here
};
