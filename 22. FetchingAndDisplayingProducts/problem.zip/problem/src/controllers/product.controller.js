// Import the necessary modules here

export default class ProductController {
  getProducts = (req, res) => {
    //  Write your code here
  };
}
