// Please don't change the pre-written code
// Import the necessary modules here

export default class ProductController {
  getProducts = (req, res) => {
    // Write your code here
  };
}
