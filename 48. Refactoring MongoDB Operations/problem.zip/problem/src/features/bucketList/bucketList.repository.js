// Please don't change the pre-written code
// Import the necessary modules here

class BucketListRepository {
  async addBucketListItem(bucketListItem) {
    // Write your code here
  }

  async findOneBucketListItem(title) {
    // Write your code here
  }
}

export default BucketListRepository;
