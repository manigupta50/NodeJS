import express from "express";
const router = express.Router();

// TODO: require your artPiecesController here

// TODO: Implement your artPieces routes here

export default router;
