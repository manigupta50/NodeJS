import express from "express";
const app = express();

// TODO: require your artPieceRoutes here

app.use(express.json());

// TODO: use your artPieceRoutes with a proper endpoint

export default app;
