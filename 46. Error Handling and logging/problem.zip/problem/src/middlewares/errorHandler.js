// Please don't change the pre-written code
// Import the necessary modules here

export class customErrorHandler extends Error {
  // Write your code here
}

export const errorHandlerMiddleware = (err, req, res, next) => {
  // Write your code here
};
