// Please don't change the pre-written code
// Import the necessary modules here

export const connectUsingMongoose = async () => {
  // write your code here
};
