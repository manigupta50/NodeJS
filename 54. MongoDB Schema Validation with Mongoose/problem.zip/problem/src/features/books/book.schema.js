// Please don't change the pre-written code
// make the necessary imports for creating book schema named 'bookSchema'

// Start writing your code here

export default bookSchema;
