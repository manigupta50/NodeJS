// Please don't change the pre-written code
// Import the necessary modules here

const basicAuthMiddleware = () => {
  // Write your code here
};

export default basicAuthMiddleware;
