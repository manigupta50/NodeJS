export const getTweets = (req, res) => {
  res.send("GET tweets called!");
};

export const createTweet = (req, res) => {
  res.send("POST tweet created!");
};
