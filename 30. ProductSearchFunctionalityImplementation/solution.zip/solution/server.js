import server from "./index.js";

server.listen(5001, () => {
  console.log("server is listening at port 5000");
});
