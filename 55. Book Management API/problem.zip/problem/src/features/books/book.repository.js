import mongoose from 'mongoose';
import { bookSchema } from './book.schema.js'



export default class BookRepository {


    // -----Change code in below functions only-----

    //book creation
    async createBook(bookData) {}

    //filtering the book by id
    async getOne(id) {}
}