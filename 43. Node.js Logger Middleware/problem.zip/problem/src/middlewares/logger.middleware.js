// Please don't change the pre-written code
// Import the necessary modules here

// Write your code here

export const loggerMiddleware = async (req, res, next) => {
  // Write your code here
};
export default loggerMiddleware;
