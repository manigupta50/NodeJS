export const auth = (req, res, next) => {
  // Write your code here
};
